package com.example.repository;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.example.model.Actor;
import com.example.utils.DatabaseConnection;

public class ActorRepository implements Repository<Actor> {

    private Connection getConnection() throws SQLException {
        return DatabaseConnection.getInstance();
    }

    @Override
    public List<Actor> findAll() throws SQLException {
        List<Actor> actors = new ArrayList<>();
        String sql = "SELECT * FROM sakila.actor";

        try (Statement myStatement = getConnection().createStatement()) {
            ResultSet myResultSet = myStatement.executeQuery(sql);
            while (myResultSet.next()) {
                Actor actor = createActor(myResultSet);
                actors.add(actor);
            }
        }
        return actors;
    }

    @Override
    public Actor getByID(Integer id) throws SQLException {
        Actor actor = null;
        String sql = "SELECT * FROM sakila.actor WHERE actor_id = ?";

        try (PreparedStatement myPreparedStatement = getConnection().prepareStatement(sql)) {
            myPreparedStatement.setInt(1, id);
            try (ResultSet myResultSet = myPreparedStatement.executeQuery()) {
                if (myResultSet.next()) {
                    actor = createActor(myResultSet);
                }
            }
        }
        return actor;

    }

    private Actor createActor(ResultSet myResultSet) throws SQLException {
        Actor a = new Actor();
        a.setActorID(myResultSet.getInt("actor_id"));
        a.setFirstName(myResultSet.getString("first_name"));
        a.setLastName(myResultSet.getString("last_name"));

        return a;
    }

    @Override
    public void save(Actor t) {
        String sqlInsert = "INSERT INTO sakila.actor (first_name, last_name) VALUES (?, ?)";
        String sqlUpdate = "UPDATE sakila.actor SET first_name = ?, last_name = ? WHERE actor_id = ?";

        try (Connection conn = getConnection()) {
            if (t.getActorID() == null) {
                try (PreparedStatement stmt = conn.prepareStatement(sqlInsert)) {
                    stmt.setString(1, t.getFirstName());
                    stmt.setString(2, t.getLastName());
                    stmt.executeUpdate();
                    System.out.println("Actor insertado con éxito.");
                }
            } else {
                try (PreparedStatement stmt = conn.prepareStatement(sqlUpdate)) {
                    stmt.setString(1, t.getFirstName());
                    stmt.setString(2, t.getLastName());
                    stmt.setInt(3, t.getActorID());
                    stmt.executeUpdate();
                    System.out.println("Actor actualizado con exito.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void delete(Integer id) {
        String sql = "DELETE FROM sakila.actor WHERE actor_id = ?";
    
        try (Connection conn = getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
    
            stmt.setInt(1, id);
            int rowsAffected = stmt.executeUpdate();
    
            if (rowsAffected > 0) {
                System.out.println("Actor eliminado con éxito.");
            } else {
                System.out.println("No se encontró actor con ese ID.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}

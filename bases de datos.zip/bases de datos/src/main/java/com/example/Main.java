package com.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import com.example.model.Actor;
import com.example.repository.ActorRepository;
import com.example.repository.Repository;
import com.example.utils.DatabaseConnection;

public class Main {
    public static void main(String[] args) {
        ActorRepository actorRepo = new ActorRepository();

        Actor nuevo = new Actor(null, "carlos", "Ramírez");
        actorRepo.save(nuevo);

        actorRepo.delete(205);
    }
}
